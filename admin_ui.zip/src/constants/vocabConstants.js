export const USER_TABLE_USERNAME_HEADER = 'User Name'
export const USER_TABLE_ROLE_HEADER = 'Role'
export const USER_TABLE_EMAIL_HEADER = 'Email'
export const USER_TABLE_ACTIONS_HEADER = 'Actions'

export const USER_TABLE_DELETE_SELECTED_BUTTON = 'Delete Selected'
